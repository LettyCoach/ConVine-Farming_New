/* Amplify Params - DO NOT EDIT
    ENV
    REGION
Amplify Params - DO NOT EDIT */

// ----- You will know which network to use in "ENV" -----
// dev: testnet
// demo: testnet
// stg: mainnet
// prod: mainnet

// const ENV = process.env.ENV; // dev, demo, stg, prod
const ENV = "dev";

// ----- Region is only Tokyo region (ap-northeast-1) -----
// const REGION = process.env.REGION; // ap-northeast-1

//require('dotenv').config();
//const PORT = process.env.PORT || 3000;
const { callPlatformMethods } = require("./core_scripts/index");
const REGION = "ap-northeast-1"

async function main(req) {

    let platform_res = [];
    //return platform_res;
    var method = req.method;
    var platform = req.platform;
    var address1, address2;
    var pair = req.pair;
    var pool = req.pool;
    var farm = req.farm;

    var amount1 = 0;
    var amount2 = 0;
    var liquidity = 0;
    let request = {};
    switch (method) {
        case "statusGet":
            address1 = req.address1;
            address2 = req.address2;
            request = { platform, pair, method, pool, farm, address1, address2 };
            break;
        case "liquidityAdd":
            address1 = req.address1;
            address2 = req.address2;
            amount1 = req.amount1;
            amount2 = req.amount2;
            request = { platform, pair, method, pool, farm, address1, address2, amount1, amount2 };
            break;
        case "liquidityRemove":
            address1 = req.address1;
            address2 = req.address2;
            liquidity = req.liquidity;
            request = { platform, pair, method, pool, farm, address1, address2, liquidity };
            break;
        case "farmingDeposit":
            address1 = req.address1;
            address2 = req.address2;
            liquidity = req.liquidity;
            request = { platform, pair, method, pool, farm, address1, address2, liquidity };
            break;
        case "farmingHarvest":
            request = { platform, pair, method, pool, farm };
            break;
        case "farmingWithdraw":
            address1 = req.address1;
            address2 = req.address2;
            liquidity = req.liquidity;
            request = { platform, pair, method, pool, farm, address1, address2, liquidity };
            break;
        default:
            break;
    }
    platform_res = await callPlatformMethods(request);
    return platform_res;
}

exports.handler = async (event) => {

    console.log("Service Core Partaking Farming");
    console.log(`${ENV} - ${REGION}`);
    console.log(event);
    console.log('path', __dirname)
    //console.log(JSON.stringify(event));
    request_data = event;
    console.log("request_data", request_data.pair);
    const platform_response = await main(request_data);
    return platform_response;
};
