## Getting Started

First, run the development server:


run following command in root Folder
```bash
   npm install


you can run follow command in order to run backend
```bash
   node index.js

   

Open [http://localhost:3000](http://localhost:3000) with postman to see the result.


for testing, you can use postman.
1. download Farm-.postman_collection.json
2. import this file to postman.