
calling.js = methods call function

platform/xxxxx.js = your method functions file
otherfile/....